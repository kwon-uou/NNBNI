package gabni;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import node.NetNode;
import mifs.MutualInformationCalculation;
import mifs.FitnessCalculation;
import gabni.Chromosome;


/**************************************************************************************************
 * A Boolean network inference from time-series gene expression data using a genetic algorithm    * 
 *                                                                                                * 
 *                                                                                                *
 *                                                                                                *
 *                                                                                                *
 * @author Shohag Barman                                                                          *
 * Combined Master's and PhD student                                                              *
 * Complex Systems Computing Lab, Ulsan university, South Korea.                                  *
 *                                                                                                *                                                                                            *
 **************************************************************************************************/      


public class GA {
	private static String NETWORK_FILE_NAME = "RBN.txt";
	public static String DATA_FILE= "NetworkTransition.txt";
	public static String OUTPUT_RESULT = "gaResult.csv";
	private List<NetNode> nodes = new ArrayList<NetNode>();
	private static ArrayList<ArrayList<Integer>> solution =  new ArrayList<ArrayList<Integer>>();
	private int generations = 0;
	private static List<Chromosome> solutions = new ArrayList<Chromosome>();
	private static double mis[][];
	private static int noOfNodes;
	private Random rnd;
	private static int size;


	public void initialize() throws Exception{

		MutualInformationCalculation mfs = new MutualInformationCalculation();
		mis = mfs.calculateMI();
		initializeNodes();		
		rnd = new Random();

	}


	private void initializeNodes() throws FileNotFoundException{
		Scanner scn = null;
		nodes.clear();
		try {
			scn = new Scanner(new File(DATA_FILE));
			ArrayList<String[]> rawData = new ArrayList<String[]>();
			String line = null;


			while(scn.hasNextLine()){
				line = scn.nextLine();
				rawData.add(line.trim().split(" +"));
			}

			noOfNodes = rawData.get(0).length;
			size = rawData.size();

			for(int i=0;i<noOfNodes;i++){
				List<Integer> nodeData = new ArrayList<Integer>();
				for(String[] arr: rawData){
					nodeData.add(Integer.parseInt(arr[i].trim()));
				}

				nodes.add(new NetNode(nodeData));
			}
		} catch (FileNotFoundException e) {
			throw e;
		}finally{
			if(scn != null)
				scn.close();
		}
	}

	private void initializeSolutions(int index){
		solutions.clear();

		for(int i=0;i<noOfNodes+10;i++){
			Chromosome c = Chromosome.createCromosome(index, noOfNodes, mis[index]);
			c.setFitness(calculateFitness(c));
			solutions.add(c);
		}


	}

	private void scaleFitness(){
		float minFitness = 9999999999999f;
		float maxFitness = 0.0f;
		float originalFitness = 0;

		for (Chromosome c: solutions) {
			float cost=calculateFitness(c);
			originalFitness=1/cost;
			if (originalFitness > maxFitness)
				maxFitness = originalFitness;
			if (originalFitness < minFitness)
				minFitness = originalFitness;

			float alphaConstant=3/maxFitness-minFitness;
			float betaConstant=1-alphaConstant*minFitness;
			float scaledFitness=alphaConstant*originalFitness+betaConstant;
			//float scaledFitness = 3*(originalFitness - minFitness)/(maxFitness - minFitness) + 1;
			c.setOriginalFitness(scaledFitness);
		}



	}


	private void applyGA(int index) throws IOException{
		generations = 0;
		initializeSolutions(index);
		double K;
		K = Math.sqrt(noOfNodes);
		int cnt = 0;

		float previousFitness = 999999999;
		float currentFitness = getCurrentFitness();
		Collections.sort(solutions);
		System.out.print("Target Gene:\n "+index);
		while (solutions.get(0).getFitness() > 0 /*&& (double)currentFitness / solutions.size() > solutions.get(0).getFitness()*/ && cnt <1000) {
			scaleFitness();
			System.out.print("\t ["+generations+"]" /*+ solutions.get(0).getFitness()*/);
			if(previousFitness == currentFitness){
				cnt++;

			}
			else{
				cnt = 0;

			}
			generations++;
			if(generations==1000)
				break;
		

			List<Chromosome> offsprings = new ArrayList<Chromosome>();

			for(int k = 0;k<K;k++){
				
				List<Chromosome> parents = RouletteWheelSelection.select(solutions, false, 2, rnd);
								
				Chromosome offspring[] = parents.get(0).crossover(parents.get(1));

				offspring[0].setFitness(calculateFitness(offspring[0]));
				offspring[1].setFitness(calculateFitness(offspring[1]));

				offspring[0].mutate();
				offspring[1].mutate();

				offsprings.add(offspring[0]);
				offsprings.add(offspring[1]);

				Collections.sort(offsprings);
			}
			for(Chromosome offspring : offsprings){
			   				
				solutions.remove(solutions.size() - 1);
				solutions.add(0, offspring);
			    
			}

            
			previousFitness = currentFitness;

			currentFitness = getCurrentFitness();
			Collections.sort(solutions);

		}
		System.out.println();


		solution.add(solutions.get(0).getSources());

	}



	public void optimizeByGA() throws IOException{


		for (int i =0; i<noOfNodes;i++) {
			applyGA(i);
			/*//System.out.println((i+1) + "\t");

			System.out.print((i+1)+"\t");

			System.out.print("\t");

			ArrayList<Integer> srcs = solution.get(i);


			for(int j=0;j<srcs.size();j++){
				System.out.print((srcs.get(j) + 1)+"\t ");


			}
			System.out.println();
*/
		}



	}


	@SuppressWarnings("resource")
	public static Hashtable<Integer, ArrayList<Integer>> showStructureOfGoldStandardNetwork() throws IOException {
		Scanner scn = new Scanner(new File(NETWORK_FILE_NAME));
		
		int src;
		@SuppressWarnings("unused")
		int interaction=0;
		int target;
		String line;
		Scanner s;
		Hashtable<Integer, ArrayList<Integer>> network = new Hashtable<Integer, ArrayList<Integer>>();
		ArrayList<Integer> temp = null;
		while (scn.hasNextLine()) {
			line = scn.nextLine();
			s = new Scanner(line);
			src = s.nextInt();
			interaction = s.nextInt();
			target = s.nextInt();
			
			if (network.containsKey(target) == false) {
				network.put(target, new ArrayList<Integer>());
			}

			if (network.containsKey(src) == false) {
				network.put(src, new ArrayList<Integer>());
			}
			
			temp = network.get(target);
			temp.add(src);
									  
		}

		ArrayList<Integer> targets = new ArrayList<Integer>();
		Enumeration<Integer> enm = network.keys();
		while (enm.hasMoreElements()) {
			targets.add(enm.nextElement());
		}

		Collections.sort(targets);
        System.out.println("The Structure of a Gold Standard Network: ");
        System.out.println("Targets:        Regulators: ");
		for (Integer trgt : targets) {
			System.out.print((trgt+1));
			System.out.print("\t");
			temp = network.get(trgt);
			
			for (Integer src1 : temp) {
				System.out.print("\t" + (src1+1));
					 
			}
			System.out.println();
		}
		System.out.println();

		scn.close();
		
		return network;

	}
	


	public static void main(String[] args) throws IOException {
		GA ga = new GA();

		showStructureOfGoldStandardNetwork();

		try{
			ga.initialize();
			//if(ga.eroneous!=null && ga.eroneous.size()>0)
			ga.optimizeByGA();

			System.out.println("Gene Regulatory Network Inferred By Genetic Algorithm:");
			System.out.println("======================================================");
			System.out.println("The network consists of N ="+noOfNodes+" Nodes and "+"E="+(noOfNodes*2)+" Edges");
			System.out.println();
			System.out.println("Targets:        Regulators:");

			// print targets and sources

			for(int i=0;i<solution.size();i++){
				System.out.print((i+1)+"\t");
				System.out.print("\t");
				ArrayList<Integer> srcs = solution.get(i);


				for(int j=0;j<srcs.size();j++){
					System.out.print((srcs.get(j) + 1)+"\t ");


				}
				System.out.println();
			}

			System.out.println();
			ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();

			Scanner scn = new Scanner(new File("NetworkTransition.txt"));

			int count = 0;
			while(scn.hasNextLine()){
				String line = scn.nextLine();
				String arr[] = line.split("\\s+");
				if(count == 0){
					for(int i=0;i<arr.length;i++){
						data.add(new ArrayList<Integer>());
					}
				}
				for(int i=0;i<arr.length;i++){
					data.get(i).add(Integer.parseInt(arr[i]));
				}
				count++;
			}

			scn.close();

			ArrayList<Integer> outputs = new ArrayList<Integer>();

			ArrayList<ArrayList<Integer>> inputs = new ArrayList<ArrayList<Integer>>();
			for(int i=0;i<data.size();i++){
				inputs.addAll(solution);
				outputs.add(i);
			}

			FitnessCalculation r = new FitnessCalculation(data);
			
			r.reconstruct(inputs, outputs);

			ArrayList<ArrayList<Integer>> rec = r.getReconstructedNetwork();


			for(int j=0;j<rec.get(0).size();j++){
				for(int i=0;i<rec.size();i++){
					System.out.print(rec.get(i).get(j)+"\t");
				}
				System.out.println();
			}

			System.out.println();
			System.out.println("Dynamics Accuracy: "+(100-r.getErrorPercentage())+"%");

			System.out.println("Identification of an interaction type: ");

			for(int i=0;i<solution.size();i++){
				ArrayList<Integer> interactionsSrcs = solution.get(i);
				for(int j=0;j<interactionsSrcs.size();j++){
					//System.out.print((srcs1.get(j))+"\t ");
					int s = interactionsSrcs.get(j) + 1;

					inferSign(i+1, s, data);

				}	

			}

		}catch(Exception e){
			e.printStackTrace();
		}


	}


	int calculateFitness(Chromosome c) {

		ArrayList<Integer> srcs =  c.getSources();


		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		for(NetNode node: nodes){
			data.add((ArrayList<Integer>)node.getData());
		}

		FitnessCalculation rec = new FitnessCalculation(data);
		int e = rec.reconstructARow(srcs, c.getTarget());
		
		e = e << 8;

		e += srcs.size();

		return e;
	}

	private float getCurrentFitness(){
		float current = 0;
		//float max=0;
		for(Chromosome c: solutions){

			if(c.getOriginalFitness()==0)
				continue;
			current= c.getOriginalFitness();
			/*if(max<current)
				max=current;*/

		}

		return current;
	}

	private static void inferSign(int t, int s, ArrayList<ArrayList<Integer>> data){

		int V_Vi_00=0;
		int V_Vi_01=0;
		int V_Vi_10=0;
		int V_Vi_11=0;


		for(int m=0; m <size-1; m++){

			if(data.get(t-1).get(m+1)== 0){
				if(data.get(s-1).get(m)== 0){
					V_Vi_00++;
				}
				else{
					V_Vi_01++;
				}

			}else{
				if(data.get(s-1).get(m)==0){
					V_Vi_10++;
				}
				else{
					V_Vi_11++;
				}

			}

		}

		if(V_Vi_00 != 0 & V_Vi_01 == 0 & V_Vi_10 == 0 & V_Vi_11 != 0){
			System.out.println("Target: "+ t+"\t" +s+"(+)"); 
		}

		else if(V_Vi_00 == 0 & V_Vi_01 != 0 & V_Vi_10 != 0 & V_Vi_11 == 0){
			System.out.println("Target: "+ t+"\t" +s+"(-)"); 
		}
		else{


			int count = ((V_Vi_00+V_Vi_11)/(V_Vi_01+V_Vi_10));

			if(count >= 1){
				System.out.println("Target: "+ t+"\t" +s+"(+)");
			}
			if(count < 1){
				System.out.println("Target: "+ t+"\t"+s+"(-)");
			}

		}
	}

}
