package mifs;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Shohag Barman
 *
 */
public class AtributeInteger {

	
	private List<Integer> tupleInteger;
	
	public AtributeInteger(){
		this.tupleInteger = new ArrayList<Integer>();
	}
		
	public List<Integer> getTupleInteger() {
		return tupleInteger;
	}

	public void setTupleInteger(List<Integer> tupleInteger) {
		this.tupleInteger = tupleInteger;
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
