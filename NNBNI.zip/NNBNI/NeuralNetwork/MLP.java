package NeuralNetwork;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/********************************************************************************
 * Multilayer perceptron (many-to-one) that takes time series data is an input  *
 * and produced output function for each target gene using general update rules.*
 * Regulator genes are given to inputs neurons and output is target gene.       *
 *                                                                              *
 *                                                                              *
 * @author Shohag Barman                                                        *                                                                    * 
 * 					                                                            *	                                                                     *
 * Combined Master's and PhD student                                            *                                                      *
 * Complex Systems Computing Lab, Ulsan university, South Korea.                *
 ********************************************************************************/

public class MLP{
	public static final int BINARY_SIGMOID = 1;
	public static final int BIPOLAR_SIGMOID = 2;
	public static final int HYPERBOLIC_TANGENT = 3;
	private static int numOfInputsNeurons;
	private static int numOfHiddenNeurons;
	private static int numOfOutputNeurons;
	private static ArrayList<ArrayList<Integer>> inputpattern =  new ArrayList<ArrayList<Integer>>();
	private static ArrayList<ArrayList<Integer>> initialInputpattern =  new ArrayList<ArrayList<Integer>>();
	private static int [] targetpattern;
	private static double inpuTohiddenWeights[][];
	private static double hiddenToOutputWeights[][];
	private static double[] delta_at_output_layer;
	private static double [] delta_at_hidden_layer;
	private static int maxIteration = 50;
	private static int patterndimension;
	private int outputDimension=1;	
	private static int [] targetOutput;
	private static double[] activatedInputsLayers;
	private static double[] activatedHiddenLayers;
	private static double[] activatedOutputLayers;
	private static int numberOfPattern;
	private static double LEARNING_RATE = 0.15;
	private static double MOMENTUM = 0.9;
	private static double[][] deltaWeightsBufferInputsToHidden;
	private static double[][] deltaWeightsBufferHideenToOutput;
	private static int numOfOutputsNeurons;
	private static int activationtype = BINARY_SIGMOID;
	private static String NETWORK_TRANSITION_FILE_NAME = "NetworkTransition.txt";
	private int initialpatternDimension;
	
	private double [] Output ;
	private static ArrayList<ArrayList<Double>> finalOutputs =  new ArrayList<ArrayList<Double>>();
	private static ArrayList<ArrayList<Integer>> data;
	//private int noOfNodes;
	//private int nodeSize;
	//private ArrayList<ArrayList<Integer>> data;
	private ArrayList<ArrayList<Integer>> recon;
	private ArrayList<Integer> errorList;
	private int noOfNodes = 0;
	private int nodeSize = 0;
		
	public int getNoOfNodes() {
		return noOfNodes;
	}

	public void setNoOfNodes(int noOfNodes) {
		this.noOfNodes = noOfNodes;
	}

	public int getNodeSize() {
		return nodeSize;
	}

	public void setNodeSize(int nodeSize) {
		this.nodeSize = nodeSize;
	}

	public MLP(ArrayList<ArrayList<Integer>> data){
		this.data = data;
		noOfNodes = data.size();
		if(noOfNodes>0)
			nodeSize = data.get(0).size();
		
		recon = new ArrayList<ArrayList<Integer>>();
		errorList = new ArrayList<Integer>();
		
	}
	
	
	public ArrayList<ArrayList<Integer>> getReconstructedNetwork() {
		return recon;
	}
	
	public ArrayList<Integer> getErrorList(){
		return errorList;
	}
	

	public void loadData() throws Exception{
		ArrayList<String> lines = new ArrayList<String>();
		Scanner scn = new Scanner(new File(NETWORK_TRANSITION_FILE_NAME));
		while (scn.hasNextLine()) {
			lines.add(scn.nextLine());
		}
		scn.close();
		nodeSize = lines.size();
		//System.out.println(noOfNodes);
		if(nodeSize<1)
			throw new Exception("No Data");
		
		scn = new Scanner(lines.get(0));
		
		noOfNodes = 0;
		data = new ArrayList<ArrayList<Integer>>();
		while (scn.hasNextInt()) {
			scn.nextDouble();
			noOfNodes++;
			data.add(new ArrayList<Integer>());
		}
		
		scn.close();
		
		for(int i=0;i<lines.size();i++){
			int j=0;
			scn = new Scanner(lines.get(i));
			while (scn.hasNextInt()) {
				data.get(j++).add(scn.nextInt());
			}
			scn.close();
		}
		
	}
public void MainNeuralNetwork() throws FileNotFoundException{
		
		TrainInputAndOutputData();
						
		//getTrainingAccuracy(targetpattern, Output);
	}
	
public void TrainInputAndOutputData() throws FileNotFoundException{
	int targetGene = 2;
	ArrayList<ArrayList<Integer>> solution = new ArrayList<ArrayList<Integer>>();
	ArrayList<Integer> regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(4);
	regulatorGenes.add(7);
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	
	regulatorGenes.add(3);
	regulatorGenes.add(8);
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(8);
	regulatorGenes.add(5);
	regulatorGenes.add(3);
	regulatorGenes.add(0);
	
	/**
	 * Rule:8AND 
	 */
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(6);
	
	/**
	 * Rule:5AND(~3OR(8))
	 */
	solution.add(regulatorGenes);
	
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(5);
	regulatorGenes.add(8);
	regulatorGenes.add(3);
	regulatorGenes.add(0);
	
	/**
	 * Rule: 3AND(~2AND(~6OR(~7)))
	 */
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	
	regulatorGenes.add(7);
	regulatorGenes.add(8);
	regulatorGenes.add(0);
	
	/**
	 * Rule: ~7AND~9
	 */
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(1);
	regulatorGenes.add(8);
	/**
	 * Rule: 2OR
	 */
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(5);
	regulatorGenes.add(4);
	regulatorGenes.add(1);
	/**
	 * Rule: ~3AND(10)
	 */
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(7);
	regulatorGenes.add(3);
	regulatorGenes.add(1);
	
	
	/**
	 * Rule: ~8AND(3)
	 */
	solution.add(regulatorGenes);
	
	regulatorGenes = new ArrayList<Integer>();
	regulatorGenes.add(0);
	solution.add(regulatorGenes);
	
	for(int i=0;i<solution.size();i++){
		System.out.print((i)+"\t");
		System.out.print("\t\t");
	  ArrayList<Integer> srcsGenie3 = solution.get(i);
		
		for(int j=0;j<srcsGenie3.size();j++){
			
			calculateFitnessbyMLP(srcsGenie3, i);
			
			
		}
		//System.out.println();
	}
		
    
   
    
    int regulatorNodes[][] = {	{3, 4, 5, 6, 8},
			{7},
			{4, 8, 9},
			{5, 6, 8},
			{4},
			{3, 5,8},
			{5},
			{9},
			{2},
			{7},
		};
       
    
}
	public int calculateFitnessbyMLP(List<Integer> regulatorGenes, int targetGene) throws FileNotFoundException{
		double totalAccuracy=0.0;
		int errorDistance=0;
					
		 int geneSize=regulatorGenes.size();
		 
		 targetpattern = new int [nodeSize-3];
		 for(int j=3;j<nodeSize;j++){

			 targetpattern[j-3] = data.get(targetGene).get(j);

		 }
		 numberOfPattern = nodeSize -3;


		 patterndimension = regulatorGenes.size()*3;
		 initialpatternDimension = regulatorGenes.size()*3;

		 inputpattern =  new ArrayList<ArrayList<Integer>>(patterndimension);
		 initialInputpattern =  new ArrayList<ArrayList<Integer>>(initialpatternDimension);
		 

		 for(int x=0;x<regulatorGenes.size();x++){
			 for(int y=0; y<3; y++){ 
				 ArrayList<Integer> eachRecord = new ArrayList<Integer>();
				 for(int z=y;z<nodeSize;z++){
					 eachRecord.add(data.get(regulatorGenes.get(x)).get(z));
					 

				 }

				 initialInputpattern.add(eachRecord);
			 }
		 }

		 for(int j=0;j<nodeSize-3;j++){
			 ArrayList<Integer> eachRecord = new ArrayList<Integer>();
			 for(int k=0;k<regulatorGenes.size()*3;k++){
				 eachRecord.add(initialInputpattern.get(k).get(j));
				 

			 }
			 inputpattern.add(eachRecord);
			 


		 }
		
			MultiLayerPerceptron();
			trainingInputAndOutputData(inputpattern, targetpattern);
			errorDistance = TestData(inputpattern);
			
			
			return errorDistance;
		}
	
	
	public void inferBooleanDynamics(int inpVals[][]) throws FileNotFoundException{
		int errorDistance=0;
		int targets[] = new int[inpVals.length];
		for(int i=0;i<inpVals.length;i++){
			targets[i] = i+1;
		}
		
		targetpattern = new int[nodeSize-1];
		int[][] sols;
		
		
		for(int i=0;i<targets.length;i++){
			for(int j=1;j<nodeSize;j++){
				
				targetpattern[j-1] = data.get(i).get(j);
				
			}
			
			sols = new int[inpVals[i].length][nodeSize - 1];
			numberOfPattern = nodeSize -1;
			patterndimension = inpVals[i].length;
			
			inputpattern =  new ArrayList<ArrayList<Integer>>(patterndimension);
			for(int j=0;j<nodeSize-1;j++){
				ArrayList<Integer> eachRecord = new ArrayList<Integer>();
				for(int k=0;k<inpVals[i].length;k++){
					eachRecord.add(Integer.valueOf(data.get(inpVals[i][k] - 1).get(j)));
																	
				}
				inputpattern.add(eachRecord);
				
			}
			
			
			MultiLayerPerceptron();
			trainingInputAndOutputData(inputpattern, targetpattern);
			errorDistance = TestData(inputpattern);
			
		}
	}
	
	public static int getNumOfOutputsNeurons() {
		return numOfOutputsNeurons;
	}
	public void setNumOfOutputsNeurons(int numOfOutputsNeurons) {
		MLP.numOfOutputsNeurons = numOfOutputsNeurons;
	}
	
	
	
	
	private void MultiLayerPerceptron(){
		numOfInputsNeurons = patterndimension + 1;
		numOfHiddenNeurons = numOfInputsNeurons*2;
		numOfOutputNeurons = outputDimension;
		inpuTohiddenWeights = new double[numOfInputsNeurons + 1][numOfHiddenNeurons];	//weights coming into hidden layer
		hiddenToOutputWeights = new double[numOfHiddenNeurons + 1][numOfOutputNeurons];	//weights going out of hidden layer
		activatedInputsLayers = new double[numOfInputsNeurons]; //input neuron array
		activatedHiddenLayers = new double[numOfHiddenNeurons];	//hidden neuron array
		activatedOutputLayers = new double[numOfOutputNeurons];
		numOfInputsNeurons = patterndimension;
		numOfOutputNeurons=outputDimension;
		delta_at_output_layer = new double[numOfOutputNeurons];
		delta_at_hidden_layer = new double[numOfHiddenNeurons];
		deltaWeightsBufferInputsToHidden = new double[numOfInputsNeurons + 1][numOfHiddenNeurons];
		deltaWeightsBufferHideenToOutput = new double[numOfHiddenNeurons + 1][numOfOutputNeurons];
		targetOutput = new int[numOfOutputNeurons];


		
		for(int i=0;i<=numOfInputsNeurons;i++)
		{
			for(int j=0;j<numOfHiddenNeurons;j++){
				inpuTohiddenWeights[i][j] = rand(-1.0, 1.0);
				
			}
		}
		
		for(int i=0;i<=numOfHiddenNeurons;i++){
			for(int j=0;j<numOfOutputNeurons;j++){
				hiddenToOutputWeights[i][j] = rand(-1.0, 1.0);
				
			}
		}


	}
		
	private static double ActivationFunction(double value){
		double output = 0;
		switch(activationtype){
		case 1:
			output = 1 / (1+Math.exp(-value));
			break;
		case 2:
			
			output = (2 / (1+Math.exp(-value))) - 1;
			break;
		case 3:
			output = (Math.exp(value) - Math.exp(-value))/((Math.exp(value) + Math.exp(-value)));
		default:
			output = 1 / (1+Math.exp(-value));
			break;
		}
		return output;
	}

	private static double DerivationOfActivationFunction(double value){
		double output=0;
		switch(activationtype){
		case 1:
			output = ActivationFunction(value) * (1 -ActivationFunction(value));
			break;
		case 2:
			output = 0.5 * (1 + ActivationFunction(value)) * (1 -ActivationFunction(value));
			break;
		case 3:
			output = (1 + ActivationFunction(value)) * (1 -ActivationFunction(value));
			break;
		default:
			output = ActivationFunction(value) * (1 -ActivationFunction(value));
			break;
		}
		return output;
	}

	private double rand(double a, double b) {
		return a + (b - a) * Math.random();
	}

	
	private static double [] feedforward(double [] inputs){
		double sum = 0.0;

		
		for (int i = 0; i < numOfHiddenNeurons; i++) {
			sum = 0.0;
			for (int j = 0; j < numOfInputsNeurons; j++){
				sum = sum + (activatedInputsLayers[j]*inpuTohiddenWeights[j][i]);

			}
			activatedHiddenLayers[i]= ActivationFunction(sum);
		}

		
		for (int i = 0; i < numOfOutputNeurons; i++) {
			sum = 0.0;
			for (int j = 0; j < numOfHiddenNeurons; j++){
				sum = sum + (activatedHiddenLayers[j]*hiddenToOutputWeights[j][i]);

			}
			activatedOutputLayers[i] = ActivationFunction(sum);


		}

		return activatedOutputLayers;

		
	}

	public static double backPropagation(int[] target)
	{  

		double error = 0.0;
		double SWAP;
		
		for(int k=0;k<numOfOutputNeurons;k++)
		{

			error = target[k]- activatedOutputLayers[k];
			delta_at_output_layer[k] = DerivationOfActivationFunction(activatedOutputLayers[k]) * error;
		}

		
		for(int j=0;j<numOfHiddenNeurons;j++)
		{

			error = 0.0;
			for(int k=0;k<numOfOutputNeurons;k++){ 
				error = error + delta_at_output_layer[k]*hiddenToOutputWeights[j][k]; 
			}
			delta_at_hidden_layer[j] = DerivationOfActivationFunction(activatedHiddenLayers[j]) * error;
		}
		
		for(int j=0;j<numOfHiddenNeurons;j++)
		{       
			for(int k=0;k<numOfOutputNeurons;k++)
			{            
				
				hiddenToOutputWeights[j][k] = hiddenToOutputWeights[j][k] + LEARNING_RATE * hiddenToOutputWeights[j][k] + MOMENTUM * delta_at_output_layer[k]*activatedHiddenLayers[j];


			}
		}
		
		for(int i=0;i<numOfInputsNeurons;i++)
		{        
			for(int j=0;j<numOfHiddenNeurons;j++)
			{            
			
				inpuTohiddenWeights[i][j] = inpuTohiddenWeights[i][j] + LEARNING_RATE*inpuTohiddenWeights[i][j] + MOMENTUM*delta_at_hidden_layer[j]*activatedInputsLayers[i];
				
				
			}
		} 
		
		error = 0.0;
		for(int k=0;k<numOfOutputNeurons;k++) {
			error = error + 0.5 * Math.pow((target[k]-activatedOutputLayers[k]),2);

		}


		return error; 
	}

	public int  TestData(ArrayList<ArrayList<Integer>> inputs)
	{
		double[] activatedOutput;
		int err=0;
		
		for (int p=0;p<inputs.size();p++)
		{
			for(int in=0;in<numOfInputsNeurons;in++){
				activatedInputsLayers[in]= inputs.get(p).get(in);

			}
			activatedOutput = feedforward(activatedInputsLayers);
			
			for(int j=0;j<activatedOutput.length;j++){
		    	   if(activatedOutput[j] >= 0.5){
						activatedOutput[j]=1;
					}
					else{
						activatedOutput[j]=0;
					}
		      
		        Output = new double [numberOfPattern];
				Output[p] = activatedOutput[j];
                 		
					
				
				if(targetpattern[p] != Output[p]){
					err++;

				}
				
				
		     }
			
			
			}
		
		return err;
	}


	public static void trainingInputAndOutputData(ArrayList<ArrayList<Integer>> inputs, int [] target)
	{   
		double error;
		

		for(int epoch=0;epoch<maxIteration;epoch++)
		{
			error = 0.0;
			for(int t=0;t<numberOfPattern;t++){

				for(int inp=0;inp<numOfInputsNeurons;inp++){
					activatedInputsLayers[inp]= inputs.get(t).get(inp);

				} 

				for(int O=0;O<numOfOutputNeurons;O++){
					targetOutput[O] = target[t];
					

				} 

				feedforward(activatedInputsLayers);                
				error += backPropagation(targetOutput);
				
			}

			

		}

	}

	public static void main(String[] args) throws Exception {
     ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		
		Scanner scn = new Scanner(new File("NetworkTransition.txt"));
		
		int count = 0;
		while(scn.hasNextLine()){
			String line = scn.nextLine();
			String arr[] = line.split("\\s+");
			if(count == 0){
				for(int i=0;i<arr.length;i++){
					data.add(new ArrayList<Integer>());
				}
			}
			for(int i=0;i<arr.length;i++){
				data.get(i).add(Integer.parseInt(arr[i]));
			}
			count++;
		}
		
		scn.close();
		
		MLP nn = new MLP(data);
		nn.outputDimension = 1;
		MLP.activationtype = BINARY_SIGMOID;
		nn.MainNeuralNetwork();


	}
	

}



