package util;

import java.util.ArrayList;
import java.util.List;

public class Permutation {
	
public static List<String> binaryPermutation(int dim){
		
		List<String> perms = new ArrayList<String>();
		List<String> perms1 = new ArrayList<String>();
		
		
		perms.add("0");
		perms.add("1");

		for(int i=1;i<dim;i++){
			for(String str:perms){
				perms1.add(str+"0");
				perms1.add(str+"1");
			}
			
			perms.clear();
			perms.addAll(perms1);
			perms1.clear();
		}
		
		
		return perms;
		
	}

}
