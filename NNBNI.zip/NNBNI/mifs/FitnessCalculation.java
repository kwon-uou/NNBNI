package mifs;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

/**************************************************************************************************
 * A chromosome in the GA represents a set of regulatory genes. Thus, we need to specify a        *
 * regulatory rule to evaluate its fitness.                                                       *
 *                                                                                                *
 *                                                                                                *
 *                                                                                                *
 * @author Shohag Barman                                                                          *
 * Combined Master's and PhD student                                                              *
 * Complex Systems Computing Lab, Ulsan university, South Korea.                                  *
 *                                                                                                *                                                                                            *
 **************************************************************************************************/

public class FitnessCalculation {
	private ArrayList<ArrayList<Integer>> data;
	private ArrayList<ArrayList<Integer>> recon;
	private ArrayList<Integer> errorList;
	private int noOfNodes = 0;
	private int nodeSize = 0;

	public int getNoOfNodes() {
		return noOfNodes;
	}

	public void setNoOfNodes(int noOfNodes) {
		this.noOfNodes = noOfNodes;
	}

	public int getNodeSize() {
		return nodeSize;
	}

	public void setNodeSize(int nodeSize) {
		this.nodeSize = nodeSize;
	}

	public FitnessCalculation(ArrayList<ArrayList<Integer>> data){
		this.data = data;
		noOfNodes = data.size();
		if(noOfNodes>0)
			nodeSize = data.get(0).size();

		recon = new ArrayList<ArrayList<Integer>>();
		errorList = new ArrayList<Integer>();

	}



	public ArrayList<ArrayList<Integer>> getReconstructedNetwork() {
		return recon;
	}

	public ArrayList<Integer> getErrorList(){
		return errorList;
	}

	public int getNoOfError(){
		int sum = 0;
		for(Integer error: errorList)
			sum += error;
		return sum;
	}

	public double getErrorPercentage(){
		int e = getNoOfError();
		double percentage = (e*100)/(noOfNodes*nodeSize);
		return percentage;
	}
	/**
	 * Reconstructs timeseries data
	 *
	 * @param inputs, incoming links; index starts from 0
	 * @param output, target nodes; index starts from 0
	 */
	public void reconstruct(ArrayList<ArrayList<Integer>> inputs, ArrayList<Integer> output){
		for(int i=0;i<output.size();i++){
			reconstructRow(inputs.get(i), output.get(i));
		}
	}


	public void reconstructRow(List<Integer> inputs, int output){

		int size = inputs.size();

		List<String> inputPermutations = generateBinaryPermutation(size);
		Hashtable<String, Integer> dataSummery = new Hashtable<String, Integer>();

		for(String str:inputPermutations)
			dataSummery.put(str, 0);

		ArrayList<String> keys = new ArrayList<String>();
		for(int i=0;i<nodeSize-1;i++){
			String key = "";
			for(int j: inputs){
				key += data.get(j).get(i);
			}
			keys.add(key);

			int major = dataSummery.get(key);

			if(data.get(output).get(i+1)==0){
				major--;
			}else{
				major++;
			}
			dataSummery.put(key, major);
		}

		for(String str:inputPermutations){
			int major = dataSummery.get(str);
			if(major > 0){
				dataSummery.put(str, 1);
			}
			else{
				dataSummery.put(str, 0);
			}
		}

		ArrayList<Integer> bestValue = new ArrayList<Integer>();
		bestValue.add(data.get(output).get(0));

		for(String key:keys)
			bestValue.add(dataSummery.get(key));

		recon.add(output, bestValue);
		errorList.add(getDistance(data.get(output), bestValue));
	}

 public int reconstructARow(List<Integer> inputs, int output){

		int size = inputs.size();

		List<String> inputPermutations = generateBinaryPermutation(size);
		Hashtable<String, Integer> dataSummery = new Hashtable<String, Integer>();

		for(String str:inputPermutations)
			dataSummery.put(str, 0);

		ArrayList<String> keys = new ArrayList<String>();
		for(int i=0;i<nodeSize-1;i++){
			String key = "";
			for(int j: inputs){
				key += data.get(j).get(i);
			}
			keys.add(key);
			int major = dataSummery.get(key);
			if(data.get(output).get(i+1)==0){
				major--;
			}else{
				major++;
			}
			dataSummery.put(key, major);
		}

		for(String str:inputPermutations){
			int major = dataSummery.get(str);
			if(major > 0){
				dataSummery.put(str, 1);
			}
			else{
				dataSummery.put(str, 0);
			}
		}

		ArrayList<Integer> bestValue = new ArrayList<Integer>();
		bestValue.add(data.get(output).get(0));

		for(String key:keys)
			bestValue.add(dataSummery.get(key));

		//recon.add(output, bestValue);
		return getDistance(data.get(output), bestValue);
	}

	private int getDistance(List<Integer> orig, List<Integer> rec){
		int ret = 0;
		for(int i=0;i<orig.size();i++){
			if(orig.get(i) != rec.get(i)){
				ret++;
			}
		}

		return ret;
	}



	public static List<String> generateBinaryPermutation(int size){
		List<String> permutations = new ArrayList<String>();
		permutations.add("");

		for(int i=0;i<size;i++){
			List<String> tempCombinations = new ArrayList<String>();
			for(String str:permutations){
				tempCombinations.add(str+"0");
				tempCombinations.add(str+"1");
			}
			permutations = tempCombinations;
		}

		return permutations;
	}

	public static void main(String args[]) throws FileNotFoundException{
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();

		Scanner scn = new Scanner(new File("NetworkTransition.txt"));

		int count = 0;
		while(scn.hasNextLine()){
			String line = scn.nextLine();
			String arr[] = line.split("\\s+");
			if(count == 0){
				for(int i=0;i<arr.length;i++){
					data.add(new ArrayList<Integer>());
				}
			}
			for(int i=0;i<arr.length;i++){
				data.get(i).add(Integer.parseInt(arr[i]));
			}
			count++;
		}

		scn.close();

		ArrayList<Integer> outputs = new ArrayList<Integer>();

		ArrayList<ArrayList<Integer>> inputs = new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<data.size();i++){
			inputs.add(new ArrayList<Integer>());
			outputs.add(i);
		}

		scn = new Scanner(new File("RBN.txt"));

		while(scn.hasNextLine()){
			String line = scn.nextLine();
			String arr[] = line.split("\\s+");
			int tgt = Integer.parseInt(arr[0]);
			int src = Integer.parseInt(arr[2]);

			inputs.get(tgt).add(src);
		}

		scn.close();



		FitnessCalculation r = new FitnessCalculation(data);
		r.reconstruct(inputs, outputs);

		ArrayList<ArrayList<Integer>> rec = r.getReconstructedNetwork();


		for(int j=0;j<rec.get(0).size();j++){
			for(int i=0;i<rec.size();i++){
				System.out.print(rec.get(i).get(j)+"\t");
			}
			System.out.println();
		}

		System.out.println();


	}
}