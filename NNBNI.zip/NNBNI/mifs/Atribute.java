package mifs;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Shohag Barman
 *
 */
public class Atribute {

	private List<Double> tuples;
	
	public Atribute(){
		this.tuples = new ArrayList<Double>();
	
	}
	
	public void settuples(List<Double> tuples) {
		this.tuples = tuples;
	}


	public List<Double> gettuples() {
		return tuples;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {


	}




	
}
