package ga;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
  * @author Daniel Dyer
 */
public class RouletteWheelSelection {
	
	public static List<Chromosome> select(List<Chromosome> population, boolean naturalFitnessScores, int selectionSize, Random rng) {
		
		
		double[] cumulativeFitnesses = new double[population.size()];
		cumulativeFitnesses[0] = getAdjustedFitness(population.get(0).getOrginalFitness(), naturalFitnessScores);
		for (int i = 1; i < population.size(); i++) {
			double fitness = getAdjustedFitness(population.get(i).getOrginalFitness(), naturalFitnessScores);
			cumulativeFitnesses[i] = cumulativeFitnesses[i - 1] + fitness;
		}
		List<Chromosome> selection = new ArrayList<Chromosome>(selectionSize);
		for (int i = 0; i < selectionSize; i++) {
			double randomFitness = rng.nextDouble() * cumulativeFitnesses[cumulativeFitnesses.length - 1];
			int index = Arrays.binarySearch(cumulativeFitnesses, randomFitness);
			if (index < 0) {
				// Convert negative insertion point to array index.
				index = Math.abs(index + 1);
			}
			selection.add(population.get(index));
		}
		return selection;
	}

	private static double getAdjustedFitness(double rawFitness, boolean naturalFitness) {
		if (naturalFitness) {
			return rawFitness;
		} else {
			
			
			return rawFitness == 0 ? Double.POSITIVE_INFINITY : 1 / rawFitness;
		}
	}

	
	@Override
	public String toString() {
		return "Roulette Wheel Selection";
	}
}

