package ga;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;



import mifs.MutualInformationCalculation;
import node.NetNode;
import NeuralNetwork.MLP;
import ga.Chromosome;


public class GA {
	private static String NETWORK_FILE_NAME = "RBN.txt";
	public static String DATA_FILE= "NetworkTransition.txt";
	public static String OUTPUT_RESULT = "gaResult.csv";
	private List<Integer> inputs = new ArrayList<Integer>();
	private List<NetNode> nodes = new ArrayList<NetNode>();
	private static ArrayList<ArrayList<Integer>> solution =  new ArrayList<ArrayList<Integer>>();
	private int generations = 0;
	private static List<Chromosome> solutions = new ArrayList<Chromosome>();
	private static Hashtable<Integer, ArrayList<Integer>> referenceNetwork = new Hashtable<Integer, ArrayList<Integer>>();
	
	private List<Integer> eroneous = new ArrayList<Integer>();
	private static double mis[][];
	private static int noOfNodes;
	private static int size;
	private static int FP;
	private boolean errorOccurred = false;
	
    
	
	private Random rnd;
	
	
	public void initialize() throws Exception{

		MutualInformationCalculation mfs = new MutualInformationCalculation();
		mis = mfs.calculateMI();
		initializeNodes();		
		rnd = new Random();
		
	}
	
	private void initializeInputs() throws FileNotFoundException{
		/*
		Scanner scn = null;
		sumOfNoOfSources = 0;
		try {
			scn = new Scanner(new File(INPUT_FILE_NAME));
			while(scn.hasNextInt()){
				int x = scn.nextInt();
				int y = scn.nextInt();
				inputs.add(y);
				sumOfNoOfSources += y;
			}
		} catch (FileNotFoundException e) {
			throw e;
		}finally{
			if(scn != null)
				scn.close();
		}
		*/
		
		for(int i=1;i<=noOfNodes;i++){
			if(referenceNetwork.get(i)!=null)
				inputs.add(referenceNetwork.get(i).size());
			else
				inputs.add(0);
		}
	}
	
	private void initializeReferenceNetwork() throws FileNotFoundException{
		Scanner scn = null;
		
		referenceNetwork = new Hashtable<Integer, ArrayList<Integer>>();
		
		try {
			scn = new Scanner(new File(NETWORK_FILE_NAME));
			while(scn.hasNextInt()){
				
				int src = scn.nextInt();
				int relation = scn.nextInt();
				int target = scn.nextInt();
				
				src++;
				target++;
				
				if(referenceNetwork.containsKey(target) == false){
					referenceNetwork.put(target, new ArrayList<Integer>());
				}
				
				referenceNetwork.get(target).add(src);
			}
		} catch (FileNotFoundException e) {
			throw e;
		}finally{
			if(scn != null)
				scn.close();
		}
	}
	/*
	 
	public boolean isSubset(Chromosome c){
		
		Set<Integer> thisSet = new HashSet<Integer>(c.getSources());
		Set<Integer> thatSet;

		for (Chromosome crmsm : solutions){
			thatSet = new HashSet<Integer>(crmsm.getSources());
			if(thatSet.contains(thisSet)){
				return true;
			}else if(thisSet.contains(thatSet)){
				
			}
		}
		
		return false;
		
	}*/
	
	private void initializeNodes() throws FileNotFoundException{
		Scanner scn = null;
		nodes.clear();
		try {
			scn = new Scanner(new File(DATA_FILE));
			ArrayList<String[]> rawData = new ArrayList<String[]>();
			String line = null;


			while(scn.hasNextLine()){
				line = scn.nextLine();
				rawData.add(line.trim().split(" "));
			}
			
			noOfNodes = rawData.get(0).length;
			size = rawData.size();
			
			for(int i=0;i<noOfNodes;i++){
				List<Integer> nodeData = new ArrayList<Integer>();
				for(String[] arr: rawData){
					nodeData.add(Integer.parseInt(arr[i].trim()));
				}
				
				nodes.add(new NetNode(nodeData));
			}
		} catch (FileNotFoundException e) {
			throw e;
		}finally{
			if(scn != null)
				scn.close();
		}
	}
	private void initializeSolutions(int index) throws FileNotFoundException{
		solutions.clear();
	
		for(int i=0;i<noOfNodes+10;i++){
			Chromosome c = Chromosome.createCromosome(index, noOfNodes, mis[index]);
			c.setFitness(calculateFitness(c));
			solutions.add(c);
		}
		
		
	}
	
	private void scaleFitness() throws FileNotFoundException{
		float minFitness = 9999999999999f;
		float maxFitness = 0.0f;
		float originalFitness = 0;
						
		for (Chromosome c: solutions) {  
			float cost=calculateFitness(c);
			     originalFitness=1/cost;			
			if (originalFitness > maxFitness)   
				maxFitness = originalFitness;
			if (originalFitness < minFitness)  
				minFitness = originalFitness;
			
			float alphaConstant=3/maxFitness-minFitness;
			float betaConstant=1-alphaConstant*minFitness;
			float scaledFitness=alphaConstant*originalFitness+betaConstant;
			c.setOrginalFitness(scaledFitness);
		}
 
				
	}
	
	
	private void applyGA(int index) throws IOException{
		generations = 0;
		initializeSolutions(index);
		double K;
		K = Math.sqrt(noOfNodes);
		int cnt = 0;
			
		float previousFitness = 999999999;
		float currentFitness = getTotalFitness();
		Collections.sort(solutions);
		System.out.print("Fitness of target node:\n "+index);
		while (solutions.get(0).getFitness() > 0 /*&& (double)currentFitness / solutions.size() > solutions.get(0).getFitness()*/ && cnt <1000) {
		    scaleFitness();	
			System.out.print("\t ["+generations+"]" /*+ solutions.get(0).getFitness()*/);
			if(previousFitness == currentFitness){
				//scaleFitness();
				cnt++;
				
			}
			else{
				cnt = 0;
				
			}
			generations++;
			if(generations==10)
				break;
				
		   
					
			List<Chromosome> offsprings = new ArrayList<Chromosome>();
				
			for(int k = 0;k<K;k++){
				
				// call to linear fitness scaling method
				           
				
				// Parents selection from population pool
				List<Chromosome> parents = RouletteWheelSelection.select(solutions, false, 2, rnd);
			
				Chromosome offspring[] = parents.get(0).crossover(parents.get(1));
			
				offspring[0].setFitness(calculateFitness(offspring[0]));
				offspring[1].setFitness(calculateFitness(offspring[1]));
				
				offspring[0].mutate();
				offspring[1].mutate();
						
				offsprings.add(offspring[0]);
				offsprings.add(offspring[1]);
				
				Collections.sort(offsprings);
			}
			for(Chromosome offspring : offsprings){
				//if(solutions.get(solutions.size() - 1).getFitness() > offspring.getFitness() ){
				    
					solutions.remove(solutions.size() - 1);
					solutions.add(0, offspring);
				//}
				//}else{
					//break;
				//}
			}
			
			
			previousFitness = currentFitness;
			
			currentFitness = getTotalFitness();
			Collections.sort(solutions);
				
		}
		System.out.println();
		//System.out.println("Fitness = "+ solutions.get(0).getFitness() +"    "+ solutions.get(1).getFitness()); 
	
		
		solution.add(solutions.get(0).getSources());
		//printInExcel(previousFitness,currentFitness);
		 	
	}
	
	private void printInExcel(float previousFitness, float currentFitness) throws IOException {
		String fileName = OUTPUT_RESULT;

		PrintWriter output = new PrintWriter(
				new FileOutputStream(fileName), true);// auto flush
		
			
			output.println("Adjusted Fitness = "+(previousFitness)+"\t"+ (currentFitness));
		
		output.close();
		// TODO Auto-generated method stub
		
	}

	public void optimizeByGA() throws IOException{
				
		for (int i =0; i<noOfNodes;i++) {
			applyGA(i);
			//System.out.println((i+1) + "\t");
		}
		
		
		
	}
	
	public static Hashtable<Integer, ArrayList<Integer>> showRealNetwork() throws IOException {
		Scanner scn = new Scanner(new File(NETWORK_FILE_NAME));
		
		int src;
		int interaction=0;
		int target;
		String line;
		Scanner s;
		Hashtable<Integer, ArrayList<Integer>> network = new Hashtable<Integer, ArrayList<Integer>>();
		ArrayList<Integer> temp = null;
		while (scn.hasNextLine()) {
			line = scn.nextLine();
			s = new Scanner(line);
			src = s.nextInt();
			interaction = s.nextInt();
			target = s.nextInt();
			//src++;
			//target++;
			if (network.containsKey(target) == false) {
				network.put(target, new ArrayList<Integer>());
			}

			if (network.containsKey(src) == false) {
				network.put(src, new ArrayList<Integer>());
			}
			
			temp = network.get(target);
			temp.add(src);
									  
		}

		ArrayList<Integer> targets = new ArrayList<Integer>();
		Enumeration<Integer> enm = network.keys();
		while (enm.hasMoreElements()) {
			targets.add(enm.nextElement());
		}

		Collections.sort(targets);
        System.out.println("The Real Network: ");
        System.out.println("Targets:        Regulators: ");
		for (Integer trgt : targets) {
			System.out.print((trgt+1));
			System.out.print("\t");
			temp = network.get(trgt);
			
			for (Integer src1 : temp) {
				System.out.print("\t" + (src1+1));
					 
			}
			System.out.println();
		}
		System.out.println();

		scn.close();
		//writer.close();
		return network;

	}
	
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		GA ga = new GA();
		
		showRealNetwork();
		
		long t1 = System.currentTimeMillis();
		
		try{
			ga.initialize();
			//if(ga.eroneous!=null && ga.eroneous.size()>0)
			ga.optimizeByGA();
															
			System.out.println("Gene Regulatory Network Inferred By Genetic Algorithm:");
			System.out.println("======================================================");
			System.out.println("The network consists of N ="+noOfNodes+" Nodes and "+"E="+(noOfNodes*2)+" Edges");
			System.out.println();
			System.out.println("Targets:        Regulators:");

			// print targets and sources
			
			for(int i=0;i<solution.size();i++){
				System.out.print((i+1)+"\t");
				System.out.print("\t");
				ArrayList<Integer> srcs = solution.get(i);
				
								
				for(int j=0;j<srcs.size();j++){
					System.out.print((srcs.get(j) + 1)+"\t ");
					
					
				}
				System.out.println();
			}
				
						
			System.out.println("\nLearning Time of The Genetic Algorithm: "+((System.currentTimeMillis() - t1))+" Milliseconds"+"\n");
			
			ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
			
			Scanner scn = new Scanner(new File("NetworkTransition.txt"));
			
			int count = 0;
			while(scn.hasNextLine()){
				String line = scn.nextLine();
				String arr[] = line.split("\\s+");
				if(count == 0){
					for(int i=0;i<arr.length;i++){
						data.add(new ArrayList<Integer>());
					}
				}
				for(int i=0;i<arr.length;i++){
					data.get(i).add(Integer.parseInt(arr[i]));
				}
				count++;
			}
			
			scn.close();
			
			ArrayList<Integer> outputs = new ArrayList<Integer>();
			
			ArrayList<ArrayList<Integer>> inputs = new ArrayList<ArrayList<Integer>>();
			for(int i=0;i<data.size();i++){
				inputs.addAll(solution);
				outputs.add(i);		
			}
						
			

			
				
		}catch(Exception e){
			e.printStackTrace();
		}
		

	}
			
	

		
	int calculateFitness(Chromosome c) throws FileNotFoundException {
		
		ArrayList<Integer> srcs =  c.getSources();
		
		
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		for(NetNode node: nodes){
			data.add((ArrayList<Integer>)node.getData());
		}
		
		MLP rec = new MLP(data);
		int e = rec.calculateFitnessbyMLP(srcs, c.getTarget());
		//System.out.println(e);
		e = e << 8;
		
		e += srcs.size();
		   		
		return e;
	}
	
	private float getTotalFitness(){
		float total = 0;
		float max=0;
		for(Chromosome c: solutions){
			
			if(c.getOrginalFitness()==0)
				continue;
			total= c.getOrginalFitness();	
			if(max<total)
				max=total;
			
		}
		
		return total;
	}
		

}
