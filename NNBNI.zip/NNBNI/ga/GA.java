package ga;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import mifs.MutualInformationCalculation;
import node.NetNode;
import NeuralNetwork.MLP;


public class GA {
	public static String DATA_FILE= "NetworkTransition.txt";
	public static String OUTPUT_RESULT = "gaResult.csv";
	private List<NetNode> nodes = new ArrayList<NetNode>();
	private static ArrayList<ArrayList<Integer>> solution =  new ArrayList<ArrayList<Integer>>();
	private int generations = 0;
	private static List<Chromosome> solutions = new ArrayList<Chromosome>();
	private static double mis[][];
	private static int noOfNodes;
	private static int size;
	private Random rnd;
	
	
	public void initialize() throws Exception{

		MutualInformationCalculation mfs = new MutualInformationCalculation();
		mis = mfs.calculateMI();
		initializeNodes();		
		rnd = new Random();
		
	}
			
	private void initializeNodes() throws FileNotFoundException{
		Scanner scn = null;
		nodes.clear();
		try {
			scn = new Scanner(new File(DATA_FILE));
			ArrayList<String[]> rawData = new ArrayList<String[]>();
			String line = null;


			while(scn.hasNextLine()){
				line = scn.nextLine();
				rawData.add(line.trim().split(" "));
			}
			
			noOfNodes = rawData.get(0).length;
			size = rawData.size();
			
			for(int i=0;i<noOfNodes;i++){
				List<Integer> nodeData = new ArrayList<Integer>();
				for(String[] arr: rawData){
					nodeData.add(Integer.parseInt(arr[i].trim()));
				}
				
				nodes.add(new NetNode(nodeData));
			}
		} catch (FileNotFoundException e) {
			throw e;
		}finally{
			if(scn != null)
				scn.close();
		}
	}
	private void initializeSolutions(int index) throws FileNotFoundException{
		solutions.clear();
	
		for(int i=0;i<noOfNodes+10;i++){
			Chromosome c = Chromosome.createCromosome(index, noOfNodes, mis[index]);
			c.setFitness(calculateFitness(c));
			solutions.add(c);
		}
		
		
	}
	
	private void scaleFitness() throws FileNotFoundException{
		float minFitness = 9999999999999f;
		float maxFitness = 0.0f;
		float originalFitness = 0;
						
		for (Chromosome c: solutions) {  
			float cost=calculateFitness(c);
			     originalFitness=1/cost;			
			if (originalFitness > maxFitness)   
				maxFitness = originalFitness;
			if (originalFitness < minFitness)  
				minFitness = originalFitness;
			
			float alphaConstant=3/maxFitness-minFitness;
			float betaConstant=1-alphaConstant*minFitness;
			float scaledFitness=alphaConstant*originalFitness+betaConstant;
			c.setOrginalFitness(scaledFitness);
		}
 
				
	}
	
	
	private void applyGA(int index) throws IOException{
		generations = 0;
		initializeSolutions(index);
		double K;
		K = Math.sqrt(noOfNodes);
		int cnt = 0;
			
		float previousFitness = 999999999;
		float currentFitness = getTotalFitness();
		Collections.sort(solutions);
		System.out.print("NNBNI is Running with respect to target node: "+index);
		System.out.println();
		while (solutions.get(0).getFitness() > 0 /*&& (double)currentFitness / solutions.size() > solutions.get(0).getFitness()*/ && cnt <1000) {
			scaleFitness();
			System.out.print("\t ["+generations+"]" /*+ solutions.get(0).getFitness()*/);
			if(previousFitness == currentFitness){
				
				cnt++;
				
			}
			else{
				cnt = 0;
				
			}
			generations++;
			if(generations==1000)
				break;
				
		   
					
			List<Chromosome> offsprings = new ArrayList<Chromosome>();
				
			for(int k = 0;k<K;k++){
				
				// Parents selection from population pool
				List<Chromosome> parents = RouletteWheelSelection.select(solutions, false, 2, rnd);
					
				Chromosome offspring[] = parents.get(0).crossover(parents.get(1));
				
				offspring[0].setFitness(calculateFitness(offspring[0]));
				offspring[1].setFitness(calculateFitness(offspring[1]));
				
				offspring[0].mutate();
				offspring[1].mutate();
						
				offsprings.add(offspring[0]);
				offsprings.add(offspring[1]);
				
				Collections.sort(offsprings);
			}
			for(Chromosome offspring : offsprings){
							    
				solutions.remove(solutions.size() - 1);
				solutions.add(0, offspring);
				
			}
			
			
			previousFitness = currentFitness;
			
			currentFitness = getTotalFitness();
			Collections.sort(solutions);
				
		}
		System.out.println();
			
		solution.add(solutions.get(0).getSources());
		 	
	}
	
	/*******************************************************************************
	*                                                                              *
	* NNBNI is a two stage algorithm. To save time, we have used our existing      *
	* algorithm called MIBNI in the early stage and if it does not find optimal    * 
	* solutions then GA with NN will be applied in the next stage. In this code,   * 
	* GA with NN is applied  for every target gene.                                *       
	*                                                                              *
	********************************************************************************/
	
	public void optimizeByGA() throws IOException{
				
		for (int i =0; i<noOfNodes;i++) {
			applyGA(i);
			
		}
		
		
		
	}
	
	/*public static Hashtable<Integer, ArrayList<Integer>> showRealNetwork() throws IOException {
		Scanner scn = new Scanner(new File(NETWORK_FILE_NAME));
		
		int src;
		int interaction=0;
		int target;
		String line;
		Scanner s;
		Hashtable<Integer, ArrayList<Integer>> network = new Hashtable<Integer, ArrayList<Integer>>();
		ArrayList<Integer> temp = null;
		while (scn.hasNextLine()) {
			line = scn.nextLine();
			s = new Scanner(line);
			src = s.nextInt();
			interaction = s.nextInt();
			target = s.nextInt();
			//src++;
			//target++;
			if (network.containsKey(target) == false) {
				network.put(target, new ArrayList<Integer>());
			}

			if (network.containsKey(src) == false) {
				network.put(src, new ArrayList<Integer>());
			}
			
			temp = network.get(target);
			temp.add(src);
									  
		}

		ArrayList<Integer> targets = new ArrayList<Integer>();
		Enumeration<Integer> enm = network.keys();
		while (enm.hasMoreElements()) {
			targets.add(enm.nextElement());
		}

		Collections.sort(targets);
        System.out.println("The Real Network: ");
        System.out.println("Targets:        Regulators: ");
		for (Integer trgt : targets) {
			System.out.print((trgt+1));
			System.out.print("\t");
			temp = network.get(trgt);
			
			for (Integer src1 : temp) {
				System.out.print("\t" + (src1+1));
					 
			}
			System.out.println();
		}
		System.out.println();

		scn.close();
		//writer.close();
		return network;

	}
	*/
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		GA ga = new GA();
		
		//showRealNetwork();
		
		long t1 = System.currentTimeMillis();
		
		try{
			ga.initialize();
			ga.optimizeByGA();
															
			System.out.println("Gene Regulatory Network Inferred By Genetic Algorithm:");
			System.out.println("======================================================");
			System.out.println("The network consists of N ="+noOfNodes+" Nodes and "+"E="+(noOfNodes*2.5)+" Edges");
			System.out.println();
			System.out.println("Targets:        Regulators:");

			// print targets and sources
			
			for(int i=0;i<solution.size();i++){
				System.out.print((i+1)+"\t");
				System.out.print("\t");
				ArrayList<Integer> srcs = solution.get(i);
				
								
				for(int j=0;j<srcs.size();j++){
					System.out.print((srcs.get(j) + 1)+"\t ");
					
					
				}
				System.out.println();
			}
				
						
			System.out.println("\nLearning Time of The Genetic Algorithm: "+((System.currentTimeMillis() - t1))+" Milliseconds"+"\n");
			
			ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
			
			Scanner scn = new Scanner(new File("NetworkTransition.txt"));
			
			int count = 0;
			while(scn.hasNextLine()){
				String line = scn.nextLine();
				String arr[] = line.split("\\s+");
				if(count == 0){
					for(int i=0;i<arr.length;i++){
						data.add(new ArrayList<Integer>());
					}
				}
				for(int i=0;i<arr.length;i++){
					data.get(i).add(Integer.parseInt(arr[i]));
				}
				count++;
			}
			
			scn.close();
			
			ArrayList<Integer> outputs = new ArrayList<Integer>();
			
			ArrayList<ArrayList<Integer>> inputs = new ArrayList<ArrayList<Integer>>();
			for(int i=0;i<data.size();i++){
				inputs.addAll(solution);
				outputs.add(i);		
			}
						
			

			
				
		}catch(Exception e){
			e.printStackTrace();
		}
		

	}
			
	

		
	int calculateFitness(Chromosome c) throws FileNotFoundException {
		
		ArrayList<Integer> srcs =  c.getSources();
		
		
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		for(NetNode node: nodes){
			data.add((ArrayList<Integer>)node.getData());
		}
		
		MLP rec = new MLP(data);
		int e = rec.calculateFitnessbyMLP(srcs, c.getTarget());
		e = e << 8;
		
		e += srcs.size();
		   	
		return e;
	}
	
	private float getTotalFitness(){
		float total = 0;
		float max=0;
		for(Chromosome c: solutions){
			
			if(c.getOrginalFitness()==0)
				continue;
			total= c.getOrginalFitness();	
			if(max<total)
				max=total;
			
		}
		
		return total;
	}
		

}
